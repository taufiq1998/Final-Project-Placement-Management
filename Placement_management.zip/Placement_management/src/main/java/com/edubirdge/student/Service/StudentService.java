package com.edubirdge.student.Service;

import java.util.List;

import com.edubirdge.student.Entities.Student;

public interface StudentService {
	
	List<Student> getAllStudents();
	
	void saveStudent(Student student);
	
	Student getStudentById(long id);
	
	void deleteStudentById(long id);

	

}
